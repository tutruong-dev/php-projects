<?php
// Close connection
mysqli_close($conn);

?>